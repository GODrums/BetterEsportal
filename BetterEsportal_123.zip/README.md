<p align="center">
  <a href="https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi">
    <img width="128" src="https://raw.githubusercontent.com/GODrums/BetterEsportal/main/img/betteresportal_logo128.png"/>
  </a>
</p>

[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/GODrums/BetterEsportal/LICENSE)
[![Chrome Web Store](https://img.shields.io/chrome-web-store/v/iklnneabdldjlpgnpccikmcgnfedlnbi.svg)](https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi)
[![Chrome Web Store](https://img.shields.io/chrome-web-store/price/iklnneabdldjlpgnpccikmcgnfedlnbi.svg)](https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi)
[![Chrome Web Store](https://img.shields.io/chrome-web-store/users/iklnneabdldjlpgnpccikmcgnfedlnbi.svg)](https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi)
[![Chrome Web Store](https://img.shields.io/chrome-web-store/stars/iklnneabdldjlpgnpccikmcgnfedlnbi.svg)](https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi)
[![Chrome Web Store](https://img.shields.io/chrome-web-store/rating-count/iklnneabdldjlpgnpccikmcgnfedlnbi.svg)](https://chrome.google.com/webstore/detail/betteresportal/iklnneabdldjlpgnpccikmcgnfedlnbi)

## NOTICE

Due to the redesign by Esportal some features and functionality is currently reworked. The main functionality has already been restored and is available in the Google Web Store.

## Developer Guide

Feel free to make contributions or open issues in this repository. While developing, please follow the license and / or shoot me an email for clarification purposes.